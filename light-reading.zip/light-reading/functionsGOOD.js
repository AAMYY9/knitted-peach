$(document).on('mousemove', function(e){
    let bugX = 0;
    let bugY = 0;
    $('.bug').css({
       left:  e.pageX,
       top:   e.pageY
    });
    $('.light').css({
       left:  e.pageX - 100,
       top:   e.pageY - 100
    });
});
